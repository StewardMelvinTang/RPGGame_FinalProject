# RPG Game - Created For I2P (II) Final Project

Team Member:
Steward Melvin Tang (112006223), Steven Ernest Liawen (112006224), Marvin Chandra (112006274)

---

<style>
table th{
    width: 100%;
}
</style>
